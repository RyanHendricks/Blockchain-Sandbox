angular.module('bc-manufacturer')

.controller('OrdersCtrl', ['$scope', function ($scope) {

}]);
