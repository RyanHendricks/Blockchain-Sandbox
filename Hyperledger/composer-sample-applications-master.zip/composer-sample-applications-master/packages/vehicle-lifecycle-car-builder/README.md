# Blockchain - Car Builder

This Vehicle-Lifecycle Car Builder application was created using the Ionic framework. 

### App Dependencies

Install Ionic and Cordova:

    npm install -g ionic cordova

### Run the app

Build the app:

    npm run build

Run the app:
    
    npm start

### Configuration

Application configuration can be found in `config/default.json`
